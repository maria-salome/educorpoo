function enviartest() {
    let respuestasCorrectas=["a","b","c","d","a","b","c","d","a","b"];
    let respuestasUsuario=new Array();
    let respuestasPregunta=new Array();
    let aciertos=0;
    let countPreguntas=0;
    for (var i=0; i<10;i++) {
        respuestasPregunta=document.getElementsByName('p'+(i+1));
        for (var j=0; j<=3;j++) {
            if (respuestasPregunta[j].checked==true) {
              countPreguntas++;
              respuestasUsuario[i]=respuestasPregunta[j].value;
              if (respuestasPregunta[j].value==respuestasCorrectas[i]) {
                aciertos++;
              }  
            }
            
        }
        
    }
    for (var i=0; i<10;i++) {
        console.log("Respuesta"+(i+1)+" "+respuestasUsuario[i])
    }
    if (countPreguntas==10) {
        alert("El test ha sido enviado con exito");
        html="<table class= 'table'>";
        html+="<tr>";
        html+="<td>Pregunta</td>";
        html+="<td>Respuesta Usuario</td>";
        html+="<td>Respuesta Correcta</td>";
        html+="<tr>";
        for (var i=0; i<10;i++) {
            html+="<tr>";
            html+="<td>"+(i+1)+"</td>";
            html+="<td>"+respuestasUsuario[i]+"</td>";
            html+="<td>"+respuestasCorrectas[i]+"</td>";
            html+="<tr>";  
        }
        html+="</table>";
        html+="<spam class='display-1'>Calificación "+aciertos+"</spam>"
        document.getElementById('resultado').innerHTML=html;
    }else{
        alert("Falta contestar Preguntas");
    }
}
function resettest() {
    for (var i=0; i<10;i++) {
        respuestasPregunta=document.getElementsByName('p'+(i+1));
        for (var j=0; j<=3;j++) {
            respuestasPregunta[j].checked=false;
        }
    }  
    document.getElementById('resultado').innerHTML="";
}
