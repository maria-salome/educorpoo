var contador;
function calificar(item){
    console.log(item);
    contador=item.id[0];//captura el primer caracter
    let nombre = item.id.substring(1);// captura todo menos el primer caracter
    for(i=0;i<5;i++){
        if(i<contador){
            document.getElementById((i+1)+nombre).style.color="yellow";
        }else{
            document.getElementById((i+1)+nombre).style.color="black";
        }
    }
}

function mensaje(){
    alert("Gracias por calificar nuestro sitio web usted nos dio "+contador+" estrellas")
}